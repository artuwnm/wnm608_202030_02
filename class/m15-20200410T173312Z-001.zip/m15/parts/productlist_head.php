<header style="background-color: white">

		<nav class="flex-parent">
			<ul class="flex-child flex-parent">
				<li class="flex-center"><a href="product_list.php"><img src="img/logo.png" alt="Logo" class="logowidth"></a></li>
				<div class="dropdown">
				  <div class="dropbtn">Sort By   <img src="img/dropdown.jpg" alt="#" width="11px"></div>
					 <div class="dropdown-content">
					 	<li class="js-orderby" data-orderby="date_create" data-direction="DESC"><a href="#"> Newest</a></li>
						<li class="js-orderby" data-orderby="date_create" data-direction="ASC"><a href="#"> Oldest</a></li>
						<li class="js-orderby" data-orderby="price" data-direction="DESC"><a href="#"> Most Expensive</a></li>
						<li class="js-orderby" data-orderby="price" data-direction="ASC"><a href="#"> Least Expensive</a></li>
					 </div>
				</div>
			</ul>
			<ul class="flex-parent">
				<li class="cart-value"><a href="product_cart.php"><img src="img/cart.png" alt="Cart" width="18px"></a><span>0</span></li>
			</ul>
		</nav>


		


</header>
