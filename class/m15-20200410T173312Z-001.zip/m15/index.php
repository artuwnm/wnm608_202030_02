 <!DOCTYPE html>
<html lang="en">
<head>
	<title>Fragrant</title>
	<?php include "parts/head.php"?>
</head>
<body>

<!-- heroshot -->
	<div class="view-window-full lgshow" style="background-image:url('img/background_splash.jpg')">
		<div class="container grid">
				<div class=" linecenter" style="padding-top:1.5em; padding-bottom: 1.5em"><a href="product_list.php"><img src="img/logo.png" alt="Logo" class="logowidth"></a></div>
			<div class="linecenter-sm splashpaddingtop button paddingbottomsmall"><h2><a href="homepage.php">Welcome In</a></h2></div>
		</div>
	</div>
	<div class="view-window-full lgnone smshow" style="background-image:url('img/background_splash_md.jpg')">
		<div class="container grid">
			<div class=" linecenter" style="padding-top:1.5em; padding-bottom: 1.5em"><a href="product_list.php"><img src="img/logo.png" alt="Logo" class="logowidth"></a></div>
			<div class="splashpaddingtop button paddingbottomsmall"><h2><a href="homepage.php">Welcome In</a></h2></div>
		</div>
	</div>
	<div class="view-window-full smnone" style="background-image:url('img/background_splash_sm.jpg')">
		<div class="container grid">
			<div class=" linecenter" style="padding-top:1.5em; "><a href="product_list.php"><img src="img/logo.png" alt="Logo" class="logowidth"></a></div>
			<div class="linecenter-sm splashpaddingtop button paddingbottomsmall"><h2><a href="homepage.php">Welcome In</a></h2></div>
		</div>
	</div>
		
</body>

</html>