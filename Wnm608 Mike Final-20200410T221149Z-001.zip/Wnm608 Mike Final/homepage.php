<!DOCTYPE html>
<html lang="en">
<head>
	<title>Fragrant</title>
	<?php include "parts/head.php"?>
</head>

<body>


<div class="view-window-half back" style="background-image:url('img/background_ad.jpg')"></div>

	<?php include "parts/header.php"?>
	
	<div class="contanier paddingtop paddingbottom">
	<div class="grid">
	<div class="row gutters-large">
			<div class="col-sm-12 col-lg-7"></div>
			<div class="col-sm-12 col-lg-4 linecenter-sm">
				<p><h1>Recommended Places</h1></p>
				<p><h3>Place 1 : Living Room</h3></p>
				<p><h3>Place 2 : Dining Room</h3></p>
				<p><h3>Place 3 : Bathroom</h3></p>
				<p><h3>Place 4 : Bedroom</h3></p>
				<div class="paddingtopsmall paddingbottom button"><a href="product_list.php">Shop Now</a></div>
			</div>
	</div>
	</div>
	</div>

<?php include "parts/footer.php"?>

</body>

</html>