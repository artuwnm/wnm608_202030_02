<footer class="paddingtopmiddle paddingbottomsmall" style="color:var(--color-light)">
		
		<div class="container grid">
		<div class="row gutters">
			<div class="col-sm-6 col-md-3"><h3>Help</h3>
			<p>Track Order<br>
				Customer Service<br>
				Returns</p>
			</div>
			<div class="col-sm-6 col-md-3"><h3>Information</h3>
			<p>Terms & Conditions<br>
				Discounts<br>
				Policies</p>
			</div>
			<div class="col-sm-6 col-md-3"><h3>Shipping</h3>
			<p>USA Standard<br>
				USA Express<br>
				Other Options</p>
			</div>
			<div class="col-sm-6 col-md-3 paddingbottomsmall"><h3>About Us</h3>
			<p>Mission<br>
				Social Responsibility<br>
				Careers</p>
			</div>
		</div>
		</div>

	</footer>