<header  class="adbackwhite">

		<nav class="flex-parent">
			<ul class="flex-child flex-parent">
				<li class="flex-center"><a href="product_list.php"><img src="img/logo.png" alt="Logo" class="logowidth"></a></li>
			</ul>
			<ul class="flex-parent">
				<li class="cart-value"><a href="product_cart.php"><img src="img/cart.png" alt="Cart" width="18px"></a><span>0</span></li>
			</ul>
		</nav>

</header>